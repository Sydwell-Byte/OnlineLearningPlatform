
const express=require('express');
const mysql=require('mysql');
const router=express().Router;
const db=require('./connection');


//API FOR ADDING ANOTHER STUDENT TO THE DATA BASE
	


router.get('/user/add', function(req,res){
    db.serialize(()=>{
      db.run('INSERT INTO user(student_number,student_firstname,student_lastname,student_email,Student_Course) VALUES(?,?,?,?,?)', 
      [req.body.id_number, req.body.gender, req.body.birthdate
        , req.body.marital_status, req.body.home_lang, req.body.citizenship, req.body.role], function(err) {
        if (err) {
          return console.log(err.message);
        }
        console.log("New "+req.body.id_number+" has been added");
        res.send("New "+req.body.id_number+" has been added into the database ");
      });
  });
  })

  //API FOR DELETING  STUDENT FROM THE DATABASE

router.get('/user/Delete/:id_number', function(req,res){
    db.serialize(()=>{
      db.run(' DELETE FROM user WHERE id_number= ?', 
      [req.params.id_number],(error)=>{
        if (error) {
          return console.log(error);
        }
        console.log("Data  has been added");
        res.send("Successfully deleted data from the database ");
      });
  });
  })

  //API FOR UPDATING  STUDENT FROM THE DATABASE
 
  router.get('/user/update', (req,res)=>{
    let user_det ={ 
        user_ID:req.body.id_number,
        gender:req.body.gender,
        birthdate:req.body.birthdate,
        marital_status:req.body.marital_status,
        home_lang:req.body.home_lang,
        citizenship:req.body.citizenship,  
        email:req.body.email,
        role:req.body.role  
       }
  
       {
        if (error) throw error;
        else
        {
          db.query('SELECT * from user WHERE user_ID = "'+ user_ID +'"',[user_det],function (error, results, fields){
          return res.send(results);
      })
    }       
  }
})   
   module.exports=routes;