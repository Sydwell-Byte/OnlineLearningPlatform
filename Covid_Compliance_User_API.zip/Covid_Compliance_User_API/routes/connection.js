
const mysql=require('mysql');
const express=require('express');

const db=mysql.createConnection({
    host:'localhost',
    user:'root',
    password :'',
    database:'covid_compliance.sql'
})

db.connect((error)=>{
    if (error)
    {
        console.log(error);
    }else{
        console.log('Sydwell your connected to the database');
    }
})
module.exports=db;