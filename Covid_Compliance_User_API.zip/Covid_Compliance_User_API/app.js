const express=require('express');
const mysql=require('mysql');
const app=express();
const PORT=process.env.PORT||4000;

const dbsql=require('./routes/connection');
const user_info=require('./routes/user');


app,use('user',user_info);


app.listen(PORT,()=>{
    console.log('Sydwell  your  connected and your serve is running on port '+PORT);
})