const express=require('express');
const router=express.Router();
const mysql=require('mysql');
const dbSql=require('./Connection');


//API for view data from database 

router.get('/',function(req,res){
dbSql.query('SELECT * FROM screen ',(error,row,eld)=>{
    if(error)
    {
        console.log(error);
    }else
    {
        console.log(row);
    }
})
})
//API for Deleting student database
router.delete('/user/Delete/:id_number', function(req,res){
    dbSql.serialize(()=>{
        dbSql.run(' DELETE FROM user WHERE id_number= ?', 
      [req.params.id_number],(error)=>{
        if (error) {
          return console.log(error);
        }
        console.log("Data  has been added");
        res.send("Successfully deleted data from the database ");
      });
  });
  })

  //API for updating user id
  router.put('/user/update/:user_ID', (req,res)=>{
    let user_det ={ 
        marital_status:req.body.marital_status,
        home_lang:req.body.home_lang,
        email:req.body.email,
        role:req.body.role  
       }
       user_ID:req.body.id_number;
       {
        if (error) throw error;
        else
        {
          db.query('SELECT * from user WHERE user_ID = "'+ user_ID +'"',[user_det],
          function (error, results, fields){
          return res.send(results);
      })
    }       
  }
})   
module.exports=router;