const express=require('express');
const app=express();
const mysql=require('mysql');
const PORT=process.env.PORT||8088;
 const dbSql=require('./routes/Connection');


app.use('/',require('./routes/api'));
app.listen(PORT,()=>{
    console.log('serve its running on localhost:'+PORT);
})
